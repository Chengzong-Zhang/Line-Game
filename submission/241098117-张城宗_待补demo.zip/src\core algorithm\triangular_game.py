
import json
import pygame
import sys
import math
from collections import deque
from enum import Enum
from typing import Dict, List, Tuple, Optional


class PointState(Enum):
    EMPTY = 0
    BLACK_NODE = 1
    BLACK_LINE = 2
    WHITE_NODE = 3
    WHITE_LINE = 4

class Player(Enum):
    BLACK = 1
    WHITE = 2

class SuperkoViolationError(Exception):
    """落子后局面哈希已存在于历史记录中，触发全局同形再现禁手（Superko Rule）。"""
    pass


class TriangularGame:
    def __init__(self):
        pygame.init()
        
        # Screen settings
        self.SCREEN_WIDTH = 800
        self.SCREEN_HEIGHT = 600
        self.screen = pygame.display.set_mode((self.SCREEN_WIDTH, self.SCREEN_HEIGHT))
        pygame.display.set_caption("Triangular Grid Connection Game")
        
        # Colors
        self.WHITE = (255, 255, 255)
        self.BLACK = (0, 0, 0)
        self.GRAY = (128, 128, 128)
        self.RED = (255, 0, 0)
        self.BLUE = (0, 0, 255)
        self.LIGHT_GRAY = (200, 200, 200)
        
        # Grid settings
        self.GRID_SIZE = 9
        self.POINT_RADIUS = 8
        self.LINE_WIDTH = 3
        
        # Calculate grid positioning
        self.grid_start_x = 100
        self.grid_start_y = 100
        self.cell_size = 50
        
        # Initialize game state
        self.grid = {}  # Dictionary to store point states: (x, y) -> PointState
        self.current_player = Player.BLACK
        self.game_over = False
        self.consecutive_skips = 0  # Counts consecutive skips; game ends when both players skip

        # 显式边集合：frozenset({node1, node2})，仅用于连通性判断，渲染仍依赖 self.grid
        self.black_edges: set = set()
        self.white_edges: set = set()

        # 全局同形再现禁手：记录历史局面哈希，防止打劫循环
        self.history_hashes: set = set()

        # Initialize grid points
        self._init_grid()

        # Set initial positions
        self.grid[(0, 0)] = PointState.BLACK_NODE
        self.grid[(8, 0)] = PointState.WHITE_NODE

        # 将初始局面写入历史，防止任何操作回到起始状态
        self.history_hashes.add(self._compute_state_hash(Player.BLACK))
        
        # Skip button
        self.skip_button_rect = pygame.Rect(650, 540, 120, 40)

        # Game clock
        self.clock = pygame.time.Clock()

        # Hull caches — only recomputed after each state change, not every frame
        self._hull_black: Tuple[Optional[list], float] = (None, 0.0)
        self._hull_white: Tuple[Optional[list], float] = (None, 0.0)

        # Pre-built fonts (Font() is slow; create once, reuse every frame)
        self._font_sm  = pygame.font.Font(None, 28)
        self._font_md  = pygame.font.Font(None, 32)
        self._font_lg  = pygame.font.Font(None, 36)
        self._font_xl  = pygame.font.Font(None, 72)

    def _init_grid(self):
        """Initialize the triangular grid with empty points"""
        for y in range(self.GRID_SIZE):
            for x in range(self.GRID_SIZE - y):
                self.grid[(x, y)] = PointState.EMPTY

    # ── 局面哈希（Superko 用）────────────────────────────────────────────

    def _compute_state_hash(self, next_player: Player) -> str:
        """将当前棋盘状态 + 即将行棋方序列化为确定性哈希字符串。

        包含：
        - 所有非空格点的坐标与归属（排序后）
        - black_edges / white_edges 中的所有连线关系（排序后）
        - 即将行棋方（即落子方切换后的下一手玩家）

        哈希相等 ⟺ 局面完全相同（全局同形再现禁手判定依据）。
        """
        # 网格层：仅序列化非空点，(x, y, state_value) 升序排列
        grid_entries = sorted(
            (x, y, state.value)
            for (x, y), state in self.grid.items()
            if state != PointState.EMPTY
        )
        # 逻辑拓扑层：每条边规范化为 (min_node, max_node)，整体升序排列
        black_edge_list = sorted(tuple(sorted(e)) for e in self.black_edges)
        white_edge_list = sorted(tuple(sorted(e)) for e in self.white_edges)

        payload = [next_player.name, grid_entries, [black_edge_list, white_edge_list]]
        return json.dumps(payload, separators=(",", ":"), ensure_ascii=True)

    def _get_screen_pos(self, grid_x: int, grid_y: int) -> Tuple[int, int]:
        """Convert grid coordinates to screen coordinates"""
        # For triangular grid, each row is offset
        offset_x = grid_y * self.cell_size // 2
        screen_x = self.grid_start_x + grid_x * self.cell_size + offset_x
        screen_y = self.grid_start_y + grid_y * self.cell_size * 0.866  # sin(60°) ≈ 0.866
        return (int(screen_x), int(screen_y))
    
    def _get_grid_pos(self, screen_x: int, screen_y: int) -> Optional[Tuple[int, int]]:
        """Convert screen coordinates to grid coordinates"""
        for y in range(self.GRID_SIZE):
            for x in range(self.GRID_SIZE - y):
                pos_x, pos_y = self._get_screen_pos(x, y)
                distance = math.sqrt((screen_x - pos_x)**2 + (screen_y - pos_y)**2)
                if distance <= self.POINT_RADIUS + 5:  # Small tolerance
                    return (x, y)
        return None
    
    def _can_connect(self, pos1: Tuple[int, int], pos2: Tuple[int, int]) -> bool:
        """Check if two positions can be connected according to the rules"""
        x1, y1 = pos1
        x2, y2 = pos2
        
        # Same X axis
        if x1 == x2:
            return True
        
        # Same Y axis
        if y1 == y2:
            return True
        
        # Same diagonal (x + y = constant)
        if x1 + y1 == x2 + y2:
            return True
        
        return False
    
    def _can_connect_with_blocking(self, pos1: Tuple[int, int], pos2: Tuple[int, int], player: Player) -> bool:
        """Check if two positions can be connected without being blocked by opponent"""
        if not self._can_connect(pos1, pos2):
            return False
        
        # Get all points on the line between pos1 and pos2 (excluding endpoints)
        line_points = self._get_line_points(pos1, pos2)
        middle_points = [p for p in line_points if p != pos1 and p != pos2]
        
        # Check if any middle point is occupied by opponent
        opponent_node = PointState.WHITE_NODE if player == Player.BLACK else PointState.BLACK_NODE
        opponent_line = PointState.WHITE_LINE if player == Player.BLACK else PointState.BLACK_LINE
        
        for point in middle_points:
            if self.grid[point] in [opponent_node, opponent_line]:
                return False
        
        return True
    
    def _get_line_points(self, start: Tuple[int, int], end: Tuple[int, int]) -> List[Tuple[int, int]]:
        """Get all points on the line between start and end (inclusive)"""
        x1, y1 = start
        x2, y2 = end
        points = []
        
        if x1 == x2:  # Vertical line
            for y in range(min(y1, y2), max(y1, y2) + 1):
                if (x1, y) in self.grid:
                    points.append((x1, y))
        elif y1 == y2:  # Horizontal line
            for x in range(min(x1, x2), max(x1, x2) + 1):
                if (x, y1) in self.grid:
                    points.append((x, y1))
        elif x1 + y1 == x2 + y2:  # Diagonal line
            if x1 < x2:
                for i in range(x2 - x1 + 1):
                    x, y = x1 + i, y1 - i
                    if (x, y) in self.grid:
                        points.append((x, y))
            else:
                for i in range(x1 - x2 + 1):
                    x, y = x2 + i, y2 - i
                    if (x, y) in self.grid:
                        points.append((x, y))
        
        return points
    
    def _get_player_nodes(self, player: Player) -> List[Tuple[int, int]]:
        """Get all nodes belonging to a player"""
        target_state = PointState.BLACK_NODE if player == Player.BLACK else PointState.WHITE_NODE
        return [pos for pos, state in self.grid.items() if state == target_state]
    
    def _get_player_lines(self, player: Player) -> List[Tuple[int, int]]:
        """Get all line points belonging to a player"""
        target_state = PointState.BLACK_LINE if player == Player.BLACK else PointState.WHITE_LINE
        return [pos for pos, state in self.grid.items() if state == target_state]
    

    def _get_covered_points(self, polygon: List[Tuple[int, int]]) -> set:
        """泛洪法：从棋盘物理边缘注水，被多边形围住的点即为领土。
        返回：多边形轮廓点本身 + 其包围的所有内部网格点。
        支持自交多边形，不依赖射线法。"""
        wall_set = set(polygon)
        water_reached: set = set()
        queue: deque = deque()

        # 从三角形网格的三条物理边缘注水（x==0, y==0, x+y==8）
        for y in range(self.GRID_SIZE):
            for x in range(self.GRID_SIZE - y):
                if x == 0 or y == 0 or x + y == self.GRID_SIZE - 1:
                    if (x, y) not in wall_set:
                        water_reached.add((x, y))
                        queue.append((x, y))

        # BFS 蔓延：遇到轮廓点停止
        while queue:
            curr = queue.popleft()
            for nxt in self._get_adjacent_positions(curr):
                if nxt not in wall_set and nxt not in water_reached:
                    water_reached.add(nxt)
                    queue.append(nxt)

        # 全图所有点 - 被水淹点 = 领土（含轮廓墙体）
        all_points = {(x, y) for y in range(self.GRID_SIZE) for x in range(self.GRID_SIZE - y)}
        return all_points - water_reached

    def _get_all_shortest_grid_paths(self, start: Tuple[int, int], end: Tuple[int, int],
                                     enemies: set, max_paths: int = 50) -> List[List[Tuple[int, int]]]:
        """BFS寻路：获取避开敌军的所有等长最短格点路径（上限 max_paths 条）"""
        if start == end:
            return [[start]]

        queue = [[start]]
        shortest_paths = []
        min_length = float('inf')
        visited_at_depth = {start: 0}

        while queue:
            path = queue.pop(0)
            current = path[-1]

            if len(path) > min_length:
                continue
            if len(shortest_paths) >= max_paths:
                break

            if current == end:
                shortest_paths.append(path)
                min_length = len(path)
                continue

            for nxt in self._get_adjacent_positions(current):
                if nxt in enemies:
                    continue
                depth = len(path)
                if nxt not in visited_at_depth or visited_at_depth[nxt] >= depth:
                    visited_at_depth[nxt] = depth
                    queue.append(path + [nxt])

        return shortest_paths

    # ------------------------------------------------------------------
    # 右手摸墙法 + 拐点提取
    # ------------------------------------------------------------------
    # 6个方向向量，按屏幕坐标顺时针排列：E, SE, SW, W, NW, NE
    _DIRS_CW = [(1, 0), (0, 1), (-1, 1), (-1, 0), (0, -1), (1, -1)]

    def _get_outer_contour(self, player: Player) -> List[Tuple[int, int]]:
        """右手摸墙法：获取己方棋子的外轮廓点列表（闭合环路，不去重）。
        起点 = x 最小（相同取 y 最小）的己方点，假定从正左方进入。"""
        DIRS = self._DIRS_CW
        friendlies = set(self._get_player_nodes(player) + self._get_player_lines(player))
        if not friendlies:
            return []

        start = min(friendlies, key=lambda p: (p[0], p[1]))

        if len(friendlies) == 1:
            return [start]

        backtrack = 3                       # 初始：从正左方（西）进入
        contour: List[Tuple[int, int]] = []
        current = start
        first_out_dir = None
        max_steps = len(friendlies) * 6 + 10   # 安全上限

        for _ in range(max_steps):
            # 从 (backtrack+1)%6 开始顺时针扫描 6 个方向
            out_dir = None
            for i in range(6):
                d = (backtrack + 1 + i) % 6
                dx, dy = DIRS[d]
                nxt = (current[0] + dx, current[1] + dy)
                if nxt in friendlies:
                    out_dir = d
                    break

            if out_dir is None:
                contour.append(current)     # 孤立点
                break

            # 终止条件：回到起点且准备迈出的方向与第一步完全相同
            if first_out_dir is None:
                first_out_dir = out_dir
                contour.append(current)
            elif current == start and out_dir == first_out_dir:
                break                       # 闭合完成
            else:
                contour.append(current)

            # 移动
            dx, dy = DIRS[out_dir]
            current = (current[0] + dx, current[1] + dy)
            backtrack = (out_dir + 3) % 6

        return contour

    # ------------------------------------------------------------------

    def _compute_inner_hull_legacy(self, player: Player):
        """核心：领土计算（右手摸墙 → 动态贪心修剪）"""
        opp = Player.WHITE if player == Player.BLACK else Player.BLACK
        friendlies = set(self._get_player_nodes(player) + self._get_player_lines(player))
        enemies = set(self._get_player_nodes(opp) + self._get_player_lines(opp))
        friendly_nodes = set(self._get_player_nodes(player))

        if not friendlies:
            return None, 0.0

        # 辅助：临时闭合多边形（首尾唯一，计算前补齐）
        def get_closed(poly):
            if poly and poly[0] != poly[-1]:
                return poly + [poly[0]]
            return poly

        # Step 1: 直接调用封装好的右手摸墙法获取外轮廓
        current_poly = self._get_outer_contour(player)

        if len(current_poly) < 3:
            return None, 0.0

        # Step 2: 动态贪心修剪（泛洪法校验版，彻底替代射线法）
        while True:
            n = len(current_poly)
            if n < 3:
                break
            cur_perim = n
            cur_area = len(self._get_covered_points(current_poly))

            # 全局最优解追踪器
            best_overall_cand = None
            best_cand_perim = cur_perim
            best_cand_area = cur_area

            for i in range(n):
                for j in range(n - 1, i + 1, -1):
                    if j - i <= 1:
                        continue

                    paths = self._get_all_shortest_grid_paths(
                        current_poly[i], current_poly[j], enemies, max_paths=100)
                    if not paths:
                        continue

                    for path in paths:
                        cand_A = current_poly[:i] + path + current_poly[j + 1:]
                        cand_B = current_poly[i:j + 1] + path[::-1][1:-1]

                        for cand in (cand_A, cand_B):
                            # 去除相邻重复顶点，防止周长被假性放大
                            cand = [p for k, p in enumerate(cand) if k == 0 or p != cand[k - 1]]
                            if len(cand) < 3:
                                continue

                            cand_perim = len(cand)
                            # 连全场最优周长都比不过，直接淘汰
                            if cand_perim > best_cand_perim:
                                continue

                            # 泛洪法计算真实领土（自动处理自交情形）
                            covered = self._get_covered_points(cand)
                            cand_area = len(covered)

                            # 周长相等时领土点数没有更小，淘汰
                            if cand_perim == best_cand_perim and cand_area >= best_cand_area:
                                continue

                            # 核心资产保护：己方所有节点必须在领土内
                            if not friendly_nodes.issubset(covered):
                                continue

                            # 避障测试：领土内不能包含任何敌方点
                            if any(e in covered for e in enemies):
                                continue

                            # 当前全场第一名，更新追踪器
                            best_cand_perim = cand_perim
                            best_cand_area = cand_area
                            best_overall_cand = cand

            # 所有锚点对遍历完毕后统一结算
            if best_overall_cand is not None:
                current_poly = best_overall_cand
            else:
                break

        if len(current_poly) < 3:
            return None, 0.0

        final_covered = self._get_covered_points(current_poly)
        final_closed = get_closed(current_poly)
        screen_polygon = [self._get_screen_pos(*p) for p in final_closed]
        area = len(final_covered)
        return screen_polygon, area

    def _compute_inner_hull(self, player: Player):
        """Compute territory using the web engine's optimized contour tightening."""
        opp = Player.WHITE if player == Player.BLACK else Player.BLACK
        friendlies = set(self._get_player_nodes(player) + self._get_player_lines(player))
        enemies = set(self._get_player_nodes(opp) + self._get_player_lines(opp))
        friendly_nodes = set(self._get_player_nodes(player))

        if not friendlies:
            return None, 0.0

        def get_closed(poly):
            if poly and poly[0] != poly[-1]:
                return poly + [poly[0]]
            return poly

        def dedupe_adjacent(poly):
            return [p for k, p in enumerate(poly) if k == 0 or p != poly[k - 1]]

        def bfs_from_source(src):
            blocked = set(enemies)
            blocked.discard(src)
            dist = {src: 0}
            pred = {}
            q = deque([src])

            while q:
                curr = q.popleft()
                for nxt in self._get_adjacent_positions(curr):
                    if nxt in blocked:
                        continue
                    nd = dist[curr] + 1
                    if nxt not in dist:
                        dist[nxt] = nd
                        pred[nxt] = [curr]
                        q.append(nxt)
                    elif dist[nxt] == nd:
                        pred[nxt].append(curr)

            return dist, pred

        def reconstruct_paths(src, tgt, pred, limit=100):
            if src == tgt:
                return [[src]]

            results = []

            def build(curr, suffix):
                if len(results) >= limit:
                    return
                if curr == src:
                    results.append([src] + suffix)
                    return
                for prev in pred.get(curr, []):
                    build(prev, [curr] + suffix)

            build(tgt, [])
            return results

        current_poly = self._get_outer_contour(player)
        if len(current_poly) < 3:
            return None, 0.0

        cur_area = 0
        while True:
            n = len(current_poly)
            if n < 3:
                break

            cur_perim = n
            cur_covered = self._get_covered_points(current_poly)
            cur_area = len(cur_covered)
            best_overall_cand = None
            best_cand_perim = cur_perim
            best_cand_area = cur_area
            bfs_cache = [bfs_from_source(current_poly[i]) for i in range(n)]

            for i in range(n):
                dist_i, pred_i = bfs_cache[i]
                for j in range(n - 1, i + 1, -1):
                    arc_len = j - i
                    if arc_len <= 1:
                        continue

                    shortest_dist = dist_i.get(current_poly[j])
                    if shortest_dist is None or shortest_dist >= arc_len:
                        continue

                    paths = reconstruct_paths(current_poly[i], current_poly[j], pred_i, limit=100)
                    if not paths:
                        continue

                    for path in paths:
                        path_len = len(path)
                        path_interior = path[1:-1]
                        is_inward = all(p in cur_covered for p in path_interior)

                        if is_inward:
                            wedge = dedupe_adjacent(current_poly[i:j + 1] + list(reversed(path_interior)))
                            if len(wedge) < 3:
                                continue

                            wedge_covered = self._get_covered_points(wedge)
                            wedge_area = len(wedge_covered)
                            path_set = set(path)
                            cand_a_area = cur_area - wedge_area + 2 * (path_len - 1)
                            cand_a_perim = cur_perim - arc_len + (path_len - 1)

                            if (
                                cand_a_perim <= best_cand_perim
                                and not (cand_a_perim == best_cand_perim and cand_a_area >= best_cand_area)
                                and all(fn not in wedge_covered or fn in path_set for fn in friendly_nodes)
                            ):
                                cand_a = dedupe_adjacent(current_poly[:i] + path + current_poly[j + 1:])
                                if len(cand_a) >= 3:
                                    best_cand_perim = cand_a_perim
                                    best_cand_area = cand_a_area
                                    best_overall_cand = cand_a

                            cand_b_perim = len(wedge)
                            cand_b_area = wedge_area
                            if (
                                cand_b_perim <= best_cand_perim
                                and not (cand_b_perim == best_cand_perim and cand_b_area >= best_cand_area)
                                and friendly_nodes.issubset(wedge_covered)
                                and not any(e in wedge_covered for e in enemies)
                            ):
                                best_cand_perim = cand_b_perim
                                best_cand_area = cand_b_area
                                best_overall_cand = wedge
                        else:
                            rev_mid = list(reversed(path_interior))
                            cand_a = current_poly[:i] + path + current_poly[j + 1:]
                            cand_b = current_poly[i:j + 1] + rev_mid
                            for cand in (cand_a, cand_b):
                                cand = dedupe_adjacent(cand)
                                if len(cand) < 3:
                                    continue

                                cand_perim = len(cand)
                                if cand_perim > best_cand_perim:
                                    continue

                                covered = self._get_covered_points(cand)
                                cand_area = len(covered)
                                if cand_perim == best_cand_perim and cand_area >= best_cand_area:
                                    continue
                                if not friendly_nodes.issubset(covered):
                                    continue
                                if any(e in covered for e in enemies):
                                    continue

                                best_cand_perim = cand_perim
                                best_cand_area = cand_area
                                best_overall_cand = cand

            if best_overall_cand is not None:
                current_poly = best_overall_cand
            else:
                break

        if len(current_poly) < 3:
            return None, 0.0

        final_covered = self._get_covered_points(current_poly)
        final_closed = get_closed(current_poly)
        screen_polygon = [self._get_screen_pos(*p) for p in final_closed]
        return screen_polygon, len(final_covered)
    
    def _update_hulls(self):
        """Recompute both players' inner hull and cache the results.
        Call once after every state change instead of every frame."""
        self._hull_black = self._compute_inner_hull(Player.BLACK)
        self._hull_white = self._compute_inner_hull(Player.WHITE)

    def _draw_territory_hulls(self):
        """Render cached inner-convex-hull territory overlays with 50 % transparency."""
        overlay = pygame.Surface((self.SCREEN_WIDTH, self.SCREEN_HEIGHT), pygame.SRCALPHA)

        black_coords, black_area = self._hull_black
        white_coords, white_area = self._hull_white

        for coords, fill_col, border_col in [
            (black_coords, (30,  80, 255, 128), (0,   0, 200, 220)),
            (white_coords, (255, 50, 50,  128), (200, 0,   0, 220)),
        ]:
            if coords and len(coords) >= 3:
                pygame.draw.polygon(overlay, fill_col, coords)
                pygame.draw.polygon(overlay, border_col, coords, 2)

        self.screen.blit(overlay, (0, 0))

        # Area labels: Blue on left, Red on right
        if black_coords:
            label = self._font_sm.render(f"Blue territory: {black_area} pts", True, (0, 0, 200))
            self.screen.blit(label, (10, self.SCREEN_HEIGHT - 30))
        if white_coords:
            label = self._font_sm.render(f"Red territory:  {white_area} pts", True, (200, 0, 0))
            lw = label.get_width()
            self.screen.blit(label, (self.SCREEN_WIDTH - lw - 10, self.SCREEN_HEIGHT - 30))

    def _get_adjacent_positions(self, pos: Tuple[int, int]) -> List[Tuple[int, int]]:
        """Get all adjacent positions to a given position"""
        x, y = pos
        adjacent = []
        
        # Define the 6 possible adjacent positions for triangular grid
        possible_adjacent = [
            (x, y + 1),    # Down
            (x, y - 1),    # Up
            (x - 1, y),    # Left
            (x + 1, y),    # Right
            (x - 1, y + 1), # Down-left
            (x + 1, y - 1)  # Up-right
        ]
        
        # Filter to only include valid grid positions
        for adj_pos in possible_adjacent:
            if adj_pos in self.grid:
                adjacent.append(adj_pos)
        
        return adjacent
    
    def _check_three_point_limitation(self, new_pos: Tuple[int, int], player: Player) -> bool:
        """Check if adding a new node would violate the three-point limitation"""
        current_nodes = self._get_player_nodes(player)
        
        # Get adjacent positions to the new node
        new_adjacent_positions = self._get_adjacent_positions(new_pos)
        new_adjacent_nodes = [pos for pos in new_adjacent_positions if pos in current_nodes]
        
        # Check case 1: new node is adjacent to 2 or more existing nodes
        if len(new_adjacent_nodes) >= 2:
            return False
        
        # Check case 2: any existing node that's adjacent to the new node
        # is also adjacent to another existing node
        for adjacent_node in new_adjacent_nodes:
            adjacent_to_existing = self._get_adjacent_positions(adjacent_node)
            adjacent_existing_nodes = [pos for pos in adjacent_to_existing if pos in current_nodes]
            
            # If this existing node has another adjacent existing node, it violates the rule
            if len(adjacent_existing_nodes) >= 1:
                return False
        
        return True
    
    def _is_in_protection_zone(self, pos: Tuple[int, int], player: Player) -> bool:
        """Check if a position is in the opponent's protection zone"""
        # Get opponent's initial position
        opponent_initial = (8, 0) if player == Player.BLACK else (0, 0)
        
        # Get adjacent positions to opponent's initial node
        protected_positions = self._get_adjacent_positions(opponent_initial)
        
        return pos in protected_positions
    
    # ── 边集合辅助方法 ─────────────────────────────────────────────────────

    def _get_edges(self, player: Player) -> set:
        """返回对应玩家的显式边集合"""
        return self.black_edges if player == Player.BLACK else self.white_edges

    def _cleanup_broken_edges(self, player: Player):
        """移除因线点被删除而断裂的边（线段上有点不再属于该玩家）"""
        edges = self._get_edges(player)
        node_st = PointState.BLACK_NODE if player == Player.BLACK else PointState.WHITE_NODE
        line_st = PointState.BLACK_LINE if player == Player.BLACK else PointState.WHITE_LINE
        broken = {e for e in edges
                  if not all(self.grid.get(p) in (node_st, line_st)
                             for p in self._get_line_points(*tuple(e)))}
        edges -= broken

    def _remove_node_edges(self, node: Tuple[int, int], player: Player):
        """移除所有经过指定节点的边"""
        edges = self._get_edges(player)
        edges -= {e for e in edges if node in e}

    # ──────────────────────────────────────────────────────────────────────

    def _is_connected_to_initial(self, pos: Tuple[int, int], player: Player) -> bool:
        """通过棋盘网格（BFS）判断节点是否连通到起始节点"""
        initial_pos = (0, 0) if player == Player.BLACK else (8, 0)
        if pos == initial_pos:
            return True

        node_state = PointState.BLACK_NODE if player == Player.BLACK else PointState.WHITE_NODE
        line_state = PointState.BLACK_LINE if player == Player.BLACK else PointState.WHITE_LINE
        player_states = {node_state, line_state}

        visited = {initial_pos}
        queue = deque([initial_pos])
        while queue:
            curr = queue.popleft()
            if curr == pos:
                return True
            for nxt in self._get_adjacent_positions(curr):
                if nxt not in visited and self.grid.get(nxt) in player_states:
                    visited.add(nxt)
                    queue.append(nxt)
        return False
    
    def _restore_connections_after_removal(self, removed_positions: List[Tuple[int, int]], attacking_player: Player):
        """Restore connections for the attacking player after opponent nodes are removed"""
        attacking_nodes = self._get_player_nodes(attacking_player)
        attacking_line_state = PointState.BLACK_LINE if attacking_player == Player.BLACK else PointState.WHITE_LINE
        attacking_node_state = PointState.BLACK_NODE if attacking_player == Player.BLACK else PointState.WHITE_NODE
        
        # For each pair of attacking player's nodes, check if they can now connect
        for i in range(len(attacking_nodes)):
            for j in range(i + 1, len(attacking_nodes)):
                node1, node2 = attacking_nodes[i], attacking_nodes[j]
                
                if self._can_connect(node1, node2):
                    line_points = self._get_line_points(node1, node2)
                    
                    # Check if any of the removed positions are on this line
                    line_intersects_removal = any(pos in line_points for pos in removed_positions)
                    
                    if line_intersects_removal:
                        # Check if the line can now be established (no blocking)
                        can_establish = True
                        for point in line_points:
                            if point != node1 and point != node2:
                                current_state = self.grid[point]
                                # Check if there's still a blocking opponent piece
                                if current_state in [PointState.WHITE_NODE, PointState.WHITE_LINE, PointState.BLACK_NODE, PointState.BLACK_LINE]:
                                    if attacking_player == Player.BLACK and current_state in [PointState.WHITE_NODE, PointState.WHITE_LINE]:
                                        can_establish = False
                                        break
                                    elif attacking_player == Player.WHITE and current_state in [PointState.BLACK_NODE, PointState.BLACK_LINE]:
                                        can_establish = False
                                        break
                        
                        # If the line can be established, mark the points
                        if can_establish:
                            for point in line_points:
                                if point == node1 or point == node2:
                                    self.grid[point] = attacking_node_state
                                elif self.grid[point] == PointState.EMPTY:
                                    self.grid[point] = attacking_line_state
                            # 记录显式边
                            self._get_edges(attacking_player).add(frozenset({node1, node2}))
    
    def _remove_disconnected_components(self, player: Player):
        """Remove nodes and lines that are no longer connected to the initial node"""
        player_nodes = self._get_player_nodes(player)
        player_lines = self._get_player_lines(player)
        
        # Check each node for connectivity
        nodes_to_remove = []
        for node in player_nodes:
            if node != ((0, 0) if player == Player.BLACK else (8, 0)):  # Don't remove initial node
                if not self._is_connected_to_initial(node, player):
                    nodes_to_remove.append(node)
        
        # Remove disconnected nodes and their connected lines
        removed_positions = []
        for node in nodes_to_remove:
            self.grid[node] = PointState.EMPTY
            removed_positions.append(node)
            
            # Remove all lines connected to this node
            remaining_nodes = [n for n in player_nodes if n not in nodes_to_remove]
            for other_node in remaining_nodes:
                if self._can_connect(node, other_node):
                    line_points = self._get_line_points(node, other_node)
                    for point in line_points:
                        if point != node and point != other_node and self.grid[point] == (PointState.BLACK_LINE if player == Player.BLACK else PointState.WHITE_LINE):
                            self.grid[point] = PointState.EMPTY
                            if point not in removed_positions:
                                removed_positions.append(point)
        
        # Remove remaining orphaned lines
        lines_to_remove = []
        current_player_lines = self._get_player_lines(player)  # Get updated lines after node removal
        valid_nodes = [n for n in player_nodes if n not in nodes_to_remove]
        
        for line_pos in current_player_lines:
            connected_to_valid_nodes = 0
            for node in valid_nodes:
                if self._can_connect(line_pos, node):
                    line_points = self._get_line_points(line_pos, node)
                    if line_pos in line_points:
                        connected_to_valid_nodes += 1
                        if connected_to_valid_nodes >= 2:  # Connected to at least 2 nodes
                            break
            
            if connected_to_valid_nodes < 2:
                lines_to_remove.append(line_pos)
        
        for line_pos in lines_to_remove:
            self.grid[line_pos] = PointState.EMPTY
            if line_pos not in removed_positions:
                removed_positions.append(line_pos)
        
        # Restore connections for the opponent (attacking player)
        if removed_positions:
            attacking_player = Player.BLACK if player == Player.WHITE else Player.WHITE
            self._restore_connections_after_removal(removed_positions, attacking_player)
    
    def _handle_blocking_attack(self, new_pos: Tuple[int, int], player: Player, original_state: PointState):
        """Handle an attack: a new node placed on opponent's line.

        Step 1 – Delete line points: from the attack point, sweep each direction.
                 Skip the direction if the adjacent point is not an opponent line.
                 Otherwise delete consecutive opponent line points until hitting an
                 opponent NODE (preserve the node, stop there).
        Step 2 – Delete isolated nodes: remove opponent nodes that can no longer
                 reach their starting point via any path.
        Step 3 – Clean up orphaned lines: delete line segments whose BOTH endpoint
                 nodes were removed in step 2.
        Step 4 – Restore connections: re-establish valid direct connections for
                 both the attacker and the defender.
        """
        opponent = Player.WHITE if player == Player.BLACK else Player.BLACK
        opp_line = PointState.WHITE_LINE if player == Player.BLACK else PointState.BLACK_LINE

        if original_state != opp_line:
            return

        # 攻击前保存双方边集合快照，用于事后只还原已有边，不新建边
        saved_edges = {
            player: set(self._get_edges(player)),
            opponent: set(self._get_edges(opponent)),
        }

        # ── Step 1 ──────────────────────────────────────────────────────────────
        # Sweep each direction. Only delete collected line cells if the sweep
        # terminates at an opponent NODE — that confirms they belong to the same
        # line segment being attacked. If the sweep ends at OOB/empty the cells
        # belong to a perpendicular segment and must NOT be deleted here.
        x0, y0 = new_pos
        opp_node_state = PointState.WHITE_NODE if player == Player.BLACK else PointState.BLACK_NODE
        directions = [(1, 0), (-1, 0), (0, 1), (0, -1), (1, -1), (-1, 1)]
        for dx, dy in directions:
            nx, ny = x0 + dx, y0 + dy
            if (nx, ny) not in self.grid or self.grid[(nx, ny)] != opp_line:
                continue  # no opponent line adjacent in this direction — skip
            cells_to_delete = []
            while (nx, ny) in self.grid and self.grid[(nx, ny)] == opp_line:
                cells_to_delete.append((nx, ny))
                nx += dx
                ny += dy
            # Only delete if sweep ended at an opponent node (same segment confirmed)
            if (nx, ny) in self.grid and self.grid[(nx, ny)] == opp_node_state:
                for cell in cells_to_delete:
                    self.grid[cell] = PointState.EMPTY

        # ── Step 1.5 ── 清理因线点删除而断裂的对手边 ────────────────────────────
        self._cleanup_broken_edges(opponent)

        # ── Step 2 ──────────────────────────────────────────────────────────────
        # 用显式边集做 BFS，避免物理相邻的"路过线"误判节点为存活
        opp_start = (8, 0) if player == Player.BLACK else (0, 0)
        opp_edges = self._get_edges(opponent)
        # 构建节点邻接表
        adj: dict = {}
        for edge in opp_edges:
            a, b = tuple(edge)
            adj.setdefault(a, []).append(b)
            adj.setdefault(b, []).append(a)
        # BFS 找出从起始点可达的所有节点
        alive_nodes: set = {opp_start}
        bfs_q = deque([opp_start])
        while bfs_q:
            curr = bfs_q.popleft()
            for nxt in adj.get(curr, []):
                if nxt not in alive_nodes:
                    alive_nodes.add(nxt)
                    bfs_q.append(nxt)

        deleted_nodes: set = set()
        for node in self._get_player_nodes(opponent):
            if node not in alive_nodes:
                self.grid[node] = PointState.EMPTY
                deleted_nodes.add(node)
                self._remove_node_edges(node, opponent)  # 移除该孤立节点的所有边

        # ── Step 3 ──────────────────────────────────────────────────────────────
        # Remove orphaned line points.
        # A line point is valid only if it lies on an intact segment between two
        # SURVIVING opponent nodes (all cells on that segment are still opp_node/opp_line).
        # This handles both the "both endpoints deleted" case and the "ray" case
        # (one endpoint deleted) without over-deleting lines still anchored to start.
        opp_node_state = PointState.WHITE_NODE if opponent == Player.WHITE else PointState.BLACK_NODE
        surviving_nodes = self._get_player_nodes(opponent)  # after Step 2

        for line_pt in list(self.grid.keys()):
            if self.grid[line_pt] != opp_line:
                continue
            protected = False
            for i in range(len(surviving_nodes)):
                if protected:
                    break
                for j in range(i + 1, len(surviving_nodes)):
                    n1, n2 = surviving_nodes[i], surviving_nodes[j]
                    if not self._can_connect(n1, n2):
                        continue
                    pts = self._get_line_points(n1, n2)
                    if line_pt not in pts:
                        continue
                    # Segment is intact if every cell on it is still opponent-owned
                    if all(self.grid[p] in (opp_node_state, opp_line) for p in pts):
                        protected = True
                        break
            if not protected:
                self.grid[line_pt] = PointState.EMPTY

        # ── Step 4 ──────────────────────────────────────────────────────────────
        self._restore_edges(player, saved_edges[player])
        self._restore_edges(opponent, saved_edges[opponent])

    def _restore_edges(self, player: Player, edges_snapshot: set):
        """仅还原攻击前已存在的边，不新建从未显式连接的边。
        领土边界经过的空点不是线段，不应被赋予 LINE 状态。"""
        node_state = PointState.BLACK_NODE if player == Player.BLACK else PointState.WHITE_NODE
        line_state = PointState.BLACK_LINE if player == Player.BLACK else PointState.WHITE_LINE
        edge_set = self._get_edges(player)

        for edge in edges_snapshot:
            if edge in edge_set:
                continue
            node1, node2 = tuple(edge)
            if self.grid.get(node1) != node_state or self.grid.get(node2) != node_state:
                continue
            if not self._can_connect_with_blocking(node1, node2, player):
                continue
            for point in self._get_line_points(node1, node2):
                if point == node1 or point == node2:
                    self.grid[point] = node_state
                elif self.grid[point] == PointState.EMPTY:
                    self.grid[point] = line_state
            edge_set.add(edge)

    def _add_node_legacy(self, pos: Tuple[int, int]) -> bool:
        """Add a new node for the current player and handle auto-connection"""
        if pos not in self.grid:
            return False
        
        original_state = self.grid[pos]
        if original_state not in [PointState.EMPTY, PointState.WHITE_LINE, PointState.BLACK_LINE]:
            return False
        
        # Check protection zone - cannot place nodes in opponent's protection zone
        if self._is_in_protection_zone(pos, self.current_player):
            return False
        
        # Check three-point limitation (skip if attacking by placing on opponent line)
        opponent_line = PointState.WHITE_LINE if self.current_player == Player.BLACK else PointState.BLACK_LINE
        is_attacking_move = (original_state == opponent_line)
        
        if not is_attacking_move and not self._check_three_point_limitation(pos, self.current_player):
            return False
        
        # ── 快照当前状态，用于 Superko 违规时回滚 ───────────────────────
        grid_snapshot = dict(self.grid)
        black_edges_snapshot = set(self.black_edges)
        white_edges_snapshot = set(self.white_edges)

        # Set the new node
        node_state = PointState.BLACK_NODE if self.current_player == Player.BLACK else PointState.WHITE_NODE
        line_state = PointState.BLACK_LINE if self.current_player == Player.BLACK else PointState.WHITE_LINE

        self.grid[pos] = node_state

        # Find all existing nodes of the current player
        existing_nodes = self._get_player_nodes(self.current_player)
        existing_nodes.remove(pos)  # Remove the newly added node

        # Check for connections using blocking-aware connection check
        connected = False
        for node_pos in existing_nodes:
            if self._can_connect_with_blocking(pos, node_pos, self.current_player):
                connected = True
                # Mark all points on the line as player's line
                line_points = self._get_line_points(pos, node_pos)
                for point in line_points:
                    if self.grid[point] == PointState.EMPTY or self.grid[point] == line_state:
                        self.grid[point] = line_state
                    # Keep nodes as nodes
                    if point == pos or point == node_pos:
                        self.grid[point] = node_state
                # 记录显式边
                self._get_edges(self.current_player).add(frozenset({pos, node_pos}))

        if not connected:
            # Revert the node placement if no connection was made
            self.grid[pos] = original_state
            return False

        # Handle blocking and elimination after successful placement
        self._handle_blocking_attack(pos, self.current_player, original_state)

        # ── Superko 检查：计算结算后（切换玩家前）局面的哈希 ────────────
        next_player = Player.WHITE if self.current_player == Player.BLACK else Player.BLACK
        state_hash = self._compute_state_hash(next_player)
        if state_hash in self.history_hashes:
            # 局面重复 → 回滚所有变更，抛出禁手异常
            self.grid = grid_snapshot
            self.black_edges = black_edges_snapshot
            self.white_edges = white_edges_snapshot
            raise SuperkoViolationError(
                f"落子 {pos} 导致局面与历史某一手完全相同，触发全局同形再现禁手（Superko Rule）。"
            )

        self.history_hashes.add(state_hash)
        return True

    def _connect_all_crawl(self, player: Player):
        """攻击结束后，沿6个方向爬行重建所有可连线段。
        方向遇到友方节点→连；遇到敌方棋子→阻断；遇到空/己方线→继续。"""
        node_state = PointState.BLACK_NODE if player == Player.BLACK else PointState.WHITE_NODE
        line_state = PointState.BLACK_LINE if player == Player.BLACK else PointState.WHITE_LINE
        opp_node = PointState.WHITE_NODE if player == Player.BLACK else PointState.BLACK_NODE
        opp_line = PointState.WHITE_LINE if player == Player.BLACK else PointState.BLACK_LINE
        edges = self._get_edges(player)

        for node in self._get_player_nodes(player):
            x, y = node
            for dx, dy in [(1, 0), (-1, 0), (0, 1), (0, -1), (1, -1), (-1, 1)]:
                cx, cy = x + dx, y + dy
                path_pts = []
                while (cx, cy) in self.grid:
                    st = self.grid[(cx, cy)]
                    if st in (opp_node, opp_line):
                        break
                    if st == node_state:
                        other = (cx, cy)
                        edge = frozenset({node, other})
                        if edge not in edges:
                            for pt in path_pts:
                                if self.grid[pt] == PointState.EMPTY:
                                    self.grid[pt] = line_state
                            edges.add(edge)
                        break
                    path_pts.append((cx, cy))
                    cx += dx
                    cy += dy

    def _add_node(self, pos: Tuple[int, int]) -> bool:
        """Add a node and resolve board effects; Superko is checked by callers."""
        if pos not in self.grid:
            return False

        original_state = self.grid[pos]
        if original_state not in [PointState.EMPTY, PointState.WHITE_LINE, PointState.BLACK_LINE]:
            return False

        if self._is_in_protection_zone(pos, self.current_player):
            return False

        opponent_line = PointState.WHITE_LINE if self.current_player == Player.BLACK else PointState.BLACK_LINE
        is_attacking_move = (original_state == opponent_line)

        if not is_attacking_move and not self._check_three_point_limitation(pos, self.current_player):
            return False

        node_state = PointState.BLACK_NODE if self.current_player == Player.BLACK else PointState.WHITE_NODE
        line_state = PointState.BLACK_LINE if self.current_player == Player.BLACK else PointState.WHITE_LINE

        self.grid[pos] = node_state

        existing_nodes = self._get_player_nodes(self.current_player)
        existing_nodes.remove(pos)

        connected = False
        for node_pos in existing_nodes:
            if not self._can_connect_with_blocking(pos, node_pos, self.current_player):
                continue

            connected = True
            line_points = self._get_line_points(pos, node_pos)
            for point in line_points:
                if self.grid[point] == PointState.EMPTY or self.grid[point] == line_state:
                    self.grid[point] = line_state
                if point == pos or point == node_pos:
                    self.grid[point] = node_state
            self._get_edges(self.current_player).add(frozenset({pos, node_pos}))

        if not connected:
            self.grid[pos] = original_state
            return False

        self._handle_blocking_attack(pos, self.current_player, original_state)
        self._connect_all_crawl(self.current_player)
        return True
    
    def _switch_player(self):
        """Switch to the other player"""
        self.current_player = Player.WHITE if self.current_player == Player.BLACK else Player.BLACK

    def _is_legal_move(self, pos: Tuple[int, int], player: Player) -> bool:
        """Check move legality against the full ruleset, including Superko, without committing state."""
        grid_snapshot = dict(self.grid)
        black_edges_snapshot = set(self.black_edges)
        white_edges_snapshot = set(self.white_edges)
        current_player_snapshot = self.current_player

        try:
            self.current_player = player
            if not self._add_node(pos):
                return False
            next_player = Player.WHITE if player == Player.BLACK else Player.BLACK
            return self._compute_state_hash(next_player) not in self.history_hashes
        finally:
            self.grid = grid_snapshot
            self.black_edges = black_edges_snapshot
            self.white_edges = white_edges_snapshot
            self.current_player = current_player_snapshot

    def _has_valid_moves(self, player: Player) -> bool:
        """Return True if the given player has at least one legal move."""
        for pos in self.grid:
            if self._is_legal_move(pos, player):
                return True
        return False

    def _check_and_auto_skip(self):
        """If the current player has no valid moves, auto-skip them (up to game end)."""
        if self.game_over:
            return
        if not self._has_valid_moves(self.current_player):
            self.consecutive_skips += 1
            if self.consecutive_skips >= 2:
                self.game_over = True
            else:
                self._switch_player()
                self._check_and_auto_skip()  # check the newly active player too

    def handle_skip(self):
        """Current player skips their turn. If both players skip consecutively, game ends."""
        if self.game_over:
            return
        self.consecutive_skips += 1
        if self.consecutive_skips >= 2:
            self.game_over = True
        else:
            self._switch_player()
            self._check_and_auto_skip()
        self._update_hulls()

    def handle_click_legacy(self, pos: Tuple[int, int]):
        """Handle mouse click at screen position"""
        if self.game_over:
            return

        # Check skip button
        if self.skip_button_rect.collidepoint(pos[0], pos[1]):
            self.handle_skip()
            return

        grid_pos = self._get_grid_pos(pos[0], pos[1])
        if grid_pos:
            try:
                success = self._add_node(grid_pos)
            except SuperkoViolationError:
                success = False  # 全局同形再现禁手：静默拒绝，棋盘状态已由 _add_node 自动回滚
            if success:
                self.consecutive_skips = 0  # Reset skip counter on a real move
                self._switch_player()
                self._check_and_auto_skip()
                self._update_hulls()

    def handle_click(self, pos: Tuple[int, int]):
        """Handle mouse click at screen position."""
        if self.game_over:
            return

        if self.skip_button_rect.collidepoint(pos[0], pos[1]):
            self.handle_skip()
            return

        grid_pos = self._get_grid_pos(pos[0], pos[1])
        if not grid_pos:
            return

        grid_snapshot = dict(self.grid)
        black_edges_snapshot = set(self.black_edges)
        white_edges_snapshot = set(self.white_edges)

        success = self._add_node(grid_pos)
        if success:
            next_player = Player.WHITE if self.current_player == Player.BLACK else Player.BLACK
            state_hash = self._compute_state_hash(next_player)
            if state_hash in self.history_hashes:
                self.grid = grid_snapshot
                self.black_edges = black_edges_snapshot
                self.white_edges = white_edges_snapshot
                success = False
            else:
                self.history_hashes.add(state_hash)

        if success:
            self.consecutive_skips = 0
            self._switch_player()
            self._check_and_auto_skip()
            self._update_hulls()
    
    def draw(self):
        """Draw the game state"""
        self.screen.fill(self.WHITE)

        # Draw territory hulls behind everything else
        self._draw_territory_hulls()

        # Draw connections as direct lines between node pairs.
        # Iterating adjacent grid points would create spurious triangles at corners,
        # so instead we draw one segment per connected node pair with no intermediate nodes.
        for player_enum in [Player.BLACK, Player.WHITE]:
            p_nodes = self._get_player_nodes(player_enum)
            node_st = PointState.BLACK_NODE if player_enum == Player.BLACK else PointState.WHITE_NODE
            line_st = PointState.BLACK_LINE if player_enum == Player.BLACK else PointState.WHITE_LINE
            owned = [node_st, line_st]
            seg_color = self.BLUE if player_enum == Player.BLACK else self.RED

            for i in range(len(p_nodes)):
                for j in range(i + 1, len(p_nodes)):
                    n1, n2 = p_nodes[i], p_nodes[j]
                    if not self._can_connect(n1, n2):
                        continue
                    pts = self._get_line_points(n1, n2)
                    # Only draw if every point on the segment is owned by this player
                    if not all(self.grid[p] in owned for p in pts):
                        continue
                    # Skip if there's an intermediate node — that shorter pair will draw it
                    if any(self.grid[p] == node_st for p in pts if p != n1 and p != n2):
                        continue
                    pygame.draw.line(self.screen, seg_color,
                                     self._get_screen_pos(*n1),
                                     self._get_screen_pos(*n2),
                                     self.LINE_WIDTH)

        # Draw grid points
        for (x, y), state in self.grid.items():
            screen_x, screen_y = self._get_screen_pos(x, y)
            
            # Draw point based on state
            if state == PointState.EMPTY:
                pygame.draw.circle(self.screen, self.LIGHT_GRAY, (screen_x, screen_y), self.POINT_RADIUS)
                pygame.draw.circle(self.screen, self.GRAY, (screen_x, screen_y), self.POINT_RADIUS, 2)
            elif state == PointState.BLACK_NODE:
                pygame.draw.circle(self.screen, self.BLUE, (screen_x, screen_y), self.POINT_RADIUS)
            elif state == PointState.BLACK_LINE:
                pygame.draw.circle(self.screen, self.LIGHT_GRAY, (screen_x, screen_y), self.POINT_RADIUS // 2)
                pygame.draw.circle(self.screen, self.BLUE, (screen_x, screen_y), self.POINT_RADIUS // 2, 2)
            elif state == PointState.WHITE_NODE:
                pygame.draw.circle(self.screen, self.RED, (screen_x, screen_y), self.POINT_RADIUS)
            elif state == PointState.WHITE_LINE:
                pygame.draw.circle(self.screen, self.LIGHT_GRAY, (screen_x, screen_y), self.POINT_RADIUS // 2)
                pygame.draw.circle(self.screen, self.RED, (screen_x, screen_y), self.POINT_RADIUS // 2, 2)
        
        # Draw current player indicator
        player_text = "Blue's Turn" if self.current_player == Player.BLACK else "Red's Turn"
        color = self.BLUE if self.current_player == Player.BLACK else self.RED
        text_surface = self._font_lg.render(player_text, True, color)
        self.screen.blit(text_surface, (10, 10))

        # Draw skip button
        pygame.draw.rect(self.screen, self.GRAY, self.skip_button_rect, border_radius=6)
        pygame.draw.rect(self.screen, self.BLACK, self.skip_button_rect, 2, border_radius=6)
        skip_label = self._font_lg.render("Skip", True, self.WHITE)
        label_rect = skip_label.get_rect(center=self.skip_button_rect.center)
        self.screen.blit(skip_label, label_rect)

        # Draw game over overlay
        if self.game_over:
            overlay = pygame.Surface((self.SCREEN_WIDTH, self.SCREEN_HEIGHT), pygame.SRCALPHA)
            overlay.fill((0, 0, 0, 160))
            self.screen.blit(overlay, (0, 0))

            black_area = self._hull_black[1]
            white_area = self._hull_white[1]
            if black_area > white_area:
                winner_text, winner_color = "Blue Wins!", (120, 160, 255)
            elif white_area > black_area:
                winner_text, winner_color = "Red Wins!",  (255, 120, 120)
            else:
                winner_text, winner_color = "Draw!",      (200, 200, 200)

            over_text = self._font_xl.render("Game Over", True, self.WHITE)
            over_rect = over_text.get_rect(center=(self.SCREEN_WIDTH // 2, self.SCREEN_HEIGHT // 2 - 55))
            self.screen.blit(over_text, over_rect)

            winner_surf = self._font_xl.render(winner_text, True, winner_color)
            winner_rect = winner_surf.get_rect(center=(self.SCREEN_WIDTH // 2, self.SCREEN_HEIGHT // 2 + 10))
            self.screen.blit(winner_surf, winner_rect)

            area_text = f"Blue {black_area:.1f} △   vs   Red {white_area:.1f} △"
            area_surf = self._font_md.render(area_text, True, self.LIGHT_GRAY)
            area_rect = area_surf.get_rect(center=(self.SCREEN_WIDTH // 2, self.SCREEN_HEIGHT // 2 + 62))
            self.screen.blit(area_surf, area_rect)

        pygame.display.flip()
    
    def run(self):
        """Main game loop"""
        running = True
        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    if event.button == 1:  # Left mouse button
                        self.handle_click(event.pos)
            
            self.draw()
            self.clock.tick(60)
        
        pygame.quit()
        sys.exit()

if __name__ == "__main__":
    game = TriangularGame()
    game.run()

