创始人：zcz
愿景启发：Harmony（第一个帮我做出初始程序的人；没有 Harmony，这个游戏的程序化进程可能会无限期搁置）, zem（第一个认为这个游戏高度程序化、可以编程实现的人）, jhd（和我上课下棋做早期测试，帮我完善了三点限制）, dya（他先手一步封喉，促使我提出了起点处禁区的概念）, yhx（下午大课间经常和我下棋，帮我完善了领土不能穿越的规则）, wy（早期测试）, zz（早期测试）, lzh（早期测试）
产品经理：Gemini(3.1Pro), zcz
游戏算法工程师：zcz, Claude code(Opus4.6/Opus4.7/Sonnet4.6), Harmony, LeoYan
AI算法工程师: zcz, Claude code(Sonnet4.6), Codex(GPT5.5)
理论分析：zcz， GPT5.5(deep reasearch), Gemini(3.1Pro)
前端开发工程师：Codex(GPT5.4/GPT5.5), Claude code(Sonnet4.6), zcz
后端开发工程师：Codex(GPT5.4), Claude code(Sonnet4.6), zcz
提示词工程师：zcz, Gemini(3.1Pro/3.1Thinking)
UI设计师：zcz, Codex(GPT5.4)
UE设计师：zcz, LeoYan, Codex(GPT5.4), Pigeon
运维工程师：Codex(GPT5.4), zcz, Claude code(Sonnet4.6)
测试工程师：zcz, LeoYan, Pigeon, Rainy
内测用户：Mandy, zfp, smy, zzd, slz, zxy, Orange, Puppy, yxy, hmy, RobinTian, zjy, wyc, fjh, lh, O, lhh, lhr, jhd

